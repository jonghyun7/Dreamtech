sudo apt-get update
sudo apt-get upgerade -y

// install program
wget https://raw.githubusercontent.com/seyoung/vscode-git/master/installer/install.sh
sudo chmod +x install.sh
sudo ./install.sh

// download code
wget https://github.com/seyoung/vscode-git/archive/master.zip