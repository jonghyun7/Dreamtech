select *
from dbo.cal_res