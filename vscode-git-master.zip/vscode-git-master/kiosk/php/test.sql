select *
from dbo.cal_res_view